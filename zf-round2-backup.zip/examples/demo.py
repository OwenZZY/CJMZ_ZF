"""Worked example for the zf package.

Run from anywhere:  python3 examples/demo.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from zf import Graph, NicePathDecomposition, closure, zero_forcing_set


def main():
    # The "house" graph on external names {1, 2, 3, 4, 5}:
    # triangle 1-2-3 on top of the square 2-3-5-4.
    graph = Graph({1, 2, 3, 4, 5},
                  [(1, 2), (1, 3), (2, 3), (2, 4), (3, 5), (4, 5)])
    print(f"graph: n={graph.n}, names={graph.names}")
    print(f"edges (indices): {graph.edges}")

    # A nice path decomposition, written as bags and converted to ops.
    bags = [set(), {0}, {0, 1}, {0, 1, 2}, {1, 2}, {1, 2, 3},
            {2, 3}, {2, 3, 4}, {3, 4}, {4}, set()]
    pd = NicePathDecomposition.from_bags(bags)
    print(f"decomposition: k={pd.k}, width={pd.width}, ops={pd.ops}")

    result = zero_forcing_set(graph, pd)

    named = [graph.names[i] for i in result.zf_set]
    print(f"\nzero forcing set S (indices): {result.zf_set}")
    print(f"zero forcing set S (names):   {named}")
    print(f"fort packing F: {[sorted(f) for f in result.forts]}")
    print(f"forcing arcs A: {result.arcs.arcs()}")
    print(f"|S| = {len(result.zf_set)}, |F| = {len(result.forts)}, "
          f"width w = {pd.width}, (w+1)|F| = {(pd.width + 1) * len(result.forts)}")

    # Independent check: forcing from S blues the whole graph.
    white, _ = closure(graph, result.zf_set)
    print(f"white vertices after forcing from S: {white}")


if __name__ == "__main__":
    main()