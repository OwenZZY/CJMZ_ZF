"""Static simple graphs with a bijection between vertex indices and names."""


class Graph:
    """Simple undirected graph on vertices 0..n-1 with external names.

    vertices is either an int n (names 0..n-1, edges given as index pairs)
    or an iterable of distinct hashable names, ordered by sorted(), giving
    the bijection names[i] <-> i. Edges are unordered endpoint pairs; loops,
    unknown endpoints and duplicate edges (in either order) raise ValueError.
    The graph is not mutated after construction; no mutators are provided.
    """

    def __init__(self, vertices, edges):
        if isinstance(vertices, int):
            if vertices < 0:
                raise ValueError("vertex count must be non-negative")
            n = vertices
            names = tuple(range(n))
            index = {i: i for i in range(n)}
            by_index = True
        else:
            try:
                names = tuple(sorted(vertices))
            except TypeError as exc:
                raise ValueError("vertex names must be mutually comparable") from exc
            try:
                index = {name: i for i, name in enumerate(names)}
            except TypeError as exc:
                raise ValueError("vertex names must be hashable") from exc
            if len(index) != len(names):
                raise ValueError("vertex names must be distinct")
            n = len(names)
            by_index = False

        edge_set = set()
        for pair in edges:
            try:
                a, b = pair
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    "edge must be a pair of endpoints: %r" % (pair,)
                ) from exc
            if by_index:
                if not isinstance(a, int) or not (0 <= a < n):
                    raise ValueError("unknown vertex index %r" % (a,))
                if not isinstance(b, int) or not (0 <= b < n):
                    raise ValueError("unknown vertex index %r" % (b,))
                i, j = a, b
            else:
                try:
                    i, j = index[a], index[b]
                except (KeyError, TypeError) as exc:
                    raise ValueError(
                        "unknown endpoint in edge %r" % (pair,)
                    ) from exc
            if i == j:
                raise ValueError("loop at vertex %d is not allowed" % i)
            e = (i, j) if i < j else (j, i)
            if e in edge_set:
                raise ValueError("duplicate edge (%d, %d)" % e)
            edge_set.add(e)

        self.n = n
        self.names = names
        self.index = index
        self.edges = tuple(sorted(edge_set))
        adj = [[] for _ in range(n)]
        for i, j in self.edges:
            adj[i].append(j)
            adj[j].append(i)
        self.adj = tuple(tuple(sorted(row)) for row in adj)

    def __len__(self):
        return self.n

    def __repr__(self):
        return "Graph(n=%d, edges=%r)" % (self.n, self.edges)
