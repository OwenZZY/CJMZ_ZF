"""Zero forcing to fixation on the full graph (SPEC-v1.md §5.2).

Engine: the count scheme of Brimkov-Fast-Hicks (EJOR 273(3):889-903, 2019,
Algorithm 1), in complementary form — white-neighbor counts instead of
colored-neighbor counts.  Canon: one force per step, performed by the
eligible blue vertex of smallest index (min-heap keyed by vertex id), the
example canon of arXiv:2402.08866v1, tex:L621.  A stale-entry guard skips
popped vertices whose unique white neighbor was already forced by someone
else (the printed B-F-H pseudocode omits this guard; it is needed).
"""

from heapq import heappop, heappush


def closure(graph, blue):
    """Run zero forcing to fixation from an initial blue set.

    graph: object with attributes n (int) and adj (sequence of sequences of
        neighbor indices; simple undirected graph, 0-based).
    blue: iterable of initial blue vertex indices (duplicates tolerated).

    Returns (white, arcs): white is the sorted list of indices still white at
    fixation; arcs is the list of (u, v) forcing pairs in the order forced.
    Deterministic: at each step the eligible blue vertex of smallest index
    forces (canonical choice, tex:L621); identical inputs give identical
    outputs.
    """
    n = graph.n
    adj = graph.adj
    is_blue = bytearray(n)
    for v in blue:
        if v < 0 or v >= n:
            raise ValueError("blue vertex out of range: {!r}".format(v))
        is_blue[v] = 1

    white_count = [0] * n
    heap = []
    for u in range(n):
        if not is_blue[u]:
            continue
        count = 0
        for w in adj[u]:
            if not is_blue[w]:
                count += 1
        white_count[u] = count
        if count == 1:
            heappush(heap, u)

    arcs = []
    while heap:
        u = heappop(heap)
        if not is_blue[u] or white_count[u] != 1:
            continue  # stale entry
        v = -1
        for w in adj[u]:
            if not is_blue[w]:
                v = w
                break
        arcs.append((u, v))
        is_blue[v] = 1
        for w in adj[v]:
            if is_blue[w]:
                white_count[w] -= 1
                if white_count[w] == 1:
                    heappush(heap, w)
        count = 0
        for w in adj[v]:
            if not is_blue[w]:
                count += 1
        white_count[v] = count
        if count == 1:
            heappush(heap, v)

    white = [i for i in range(n) if not is_blue[i]]
    return white, arcs