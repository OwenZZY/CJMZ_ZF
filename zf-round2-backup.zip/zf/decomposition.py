"""Nice path decompositions stored as introduce/forget operations."""


class NicePathDecomposition:
    """Nice path decomposition as ops (v, sign), sign +1 (add) or -1 (remove).

    Op i turns bag X_i into X_{i+1}; X_0 is empty, the final bag is empty,
    and every intermediate bag is non-empty (conditions D2-D4; contiguity
    D2 is automatic since each vertex is introduced and forgotten once).
    bags is materialized once in the constructor.

    check=True replays ops and raises ValueError on any violation.
    check=False skips the structural checks (bag membership, emptiness,
    vertex range) and materializes bags with idempotent add/discard;
    signs must still be +1/-1 (equal to the ints 1/-1), otherwise replay
    is undefined and ValueError is raised regardless of check.
    """

    def __init__(self, ops, n=None, check=True):
        normalized = []
        for idx, op in enumerate(ops):
            v, sign = op
            if sign == 1:
                sign = 1
            elif sign == -1:
                sign = -1
            else:
                raise ValueError(
                    "op %d: sign must be +1 or -1, got %r" % (idx, sign)
                )
            normalized.append((v, sign))
        ops = tuple(normalized)

        if n is not None and (not isinstance(n, int) or n < 0):
            raise ValueError("n must be a non-negative integer")
        if n is None:
            n = 1 + max((v for v, _ in ops), default=-1)

        bag = set()
        bags = [frozenset()]
        last = len(ops) - 1
        for idx, (v, sign) in enumerate(ops):
            if check:
                if not isinstance(v, int):
                    raise ValueError(
                        "op %d: vertex must be an int, got %r" % (idx, v)
                    )
                if not (0 <= v < n):
                    raise ValueError(
                        "op %d: vertex %d out of range for n=%d" % (idx, v, n)
                    )
                if sign == 1 and v in bag:
                    raise ValueError(
                        "op %d: vertex %d already in bag" % (idx, v)
                    )
                if sign == -1 and v not in bag:
                    raise ValueError(
                        "op %d: vertex %d not in bag" % (idx, v)
                    )
            if sign == 1:
                bag.add(v)
            else:
                bag.discard(v)
            if check and not bag and idx != last:
                raise ValueError(
                    "op %d: intermediate bag X_%d is empty" % (idx, idx + 1)
                )
            bags.append(frozenset(bag))
        if check and bag:
            raise ValueError("final bag must be empty, got %r" % (sorted(bag),))

        self.ops = ops
        self.bags = tuple(bags)
        self.n = n
        self.k = len(ops) - 1
        self.width = max((len(b) - 1 for b in bags if b), default=-1)

    @classmethod
    def from_bags(cls, bags):
        """Derive ops from bags differing by exactly one vertex per step.

        First and last bag must be empty; a single empty bag gives ops=().
        An empty sequence of bags raises ValueError. The result is built
        with check=True, so e.g. empty intermediate bags also raise.
        """
        bags = [frozenset(b) for b in bags]
        if not bags:
            raise ValueError("need at least one bag")
        if bags[0] or bags[-1]:
            raise ValueError("first and last bags must be empty")
        ops = []
        for i in range(len(bags) - 1):
            diff = bags[i] ^ bags[i + 1]
            if len(diff) != 1:
                raise ValueError(
                    "bags %d and %d must differ by exactly one vertex"
                    % (i, i + 1)
                )
            v = next(iter(diff))
            ops.append((v, 1 if v in bags[i + 1] else -1))
        union = set()
        for b in bags:
            union |= b
        n = 1 + max(union) if union else 0
        return cls(ops, n=n)

    def validate(self, graph):
        """Check n match, vertex coverage, and D1 (edges inside a bag).

        Uses duck typing (graph.n, graph.edges). A vertex's bags form one
        interval, so edge (u, v) is covered iff the intervals overlap:
        max(first[u], first[v]) <= min(last[u], last[v]).
        Raises ValueError on failure; returns None on success.
        """
        if graph.n != self.n:
            raise ValueError(
                "graph has n=%d but decomposition has n=%d"
                % (graph.n, self.n)
            )
        first = {}
        last = {}
        for idx, bag in enumerate(self.bags):
            for v in bag:
                if v not in first:
                    first[v] = idx
                last[v] = idx
        for v in range(self.n):
            if v not in first:
                raise ValueError("vertex %d appears in no bag" % v)
        for u, v in graph.edges:
            if max(first[u], first[v]) > min(last[u], last[v]):
                raise ValueError(
                    "edge (%d, %d) is not contained in any bag" % (u, v)
                )
        return None

    def __repr__(self):
        return "NicePathDecomposition(n=%d, k=%d, width=%d)" % (
            self.n,
            self.k,
            self.width,
        )
