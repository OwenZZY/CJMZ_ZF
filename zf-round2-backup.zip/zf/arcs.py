"""Arc sets with in/out-degree at most one (vertex-disjoint dipaths)."""


class Arcs:
    """Arc set on 0..n-1; invariant out_arcs[i] == j iff in_arcs[j] == i.

    out_arcs and in_arcs are lists of length n with entries in 0..n-1 or -1
    (absent). count is maintained dynamically and len(self) == count.
    Forcing arc sets are vertex-disjoint dipaths, so each vertex has at most
    one in-arc and one out-arc, and two-way pairs are forbidden.
    """

    def __init__(self, n):
        if not isinstance(n, int) or n < 0:
            raise ValueError("n must be a non-negative integer")
        self.n = n
        self.out_arcs = [-1] * n
        self.in_arcs = [-1] * n
        self.count = 0

    def _check_index(self, v):
        if not isinstance(v, int) or not (0 <= v < self.n):
            raise ValueError(
                "vertex index %r out of range for n=%d" % (v, self.n)
            )

    def add(self, i, j):
        """Insert arc i->j; raise ValueError on any conflict."""
        self._check_index(i)
        self._check_index(j)
        if i == j:
            raise ValueError("self-loop %d->%d is not allowed" % (i, j))
        if self.out_arcs[i] != -1:
            raise ValueError("vertex %d already has an out-arc" % i)
        if self.in_arcs[j] != -1:
            raise ValueError("vertex %d already has an in-arc" % j)
        if self.out_arcs[j] == i:
            raise ValueError("reverse arc %d->%d already present" % (j, i))
        self.out_arcs[i] = j
        self.in_arcs[j] = i
        self.count += 1

    def delete(self, heads):
        """Remove the arc whose HEAD is j, for each head j in heads.

        heads is one head index (int) or an iterable of head indices.
        Heads without an in-arc are skipped silently. Returns the number
        of arcs removed. Out-of-range heads raise ValueError.
        """
        if isinstance(heads, int):
            heads = (heads,)
        removed = 0
        for j in heads:
            self._check_index(j)
            i = self.in_arcs[j]
            if i != -1:
                self.out_arcs[i] = -1
                self.in_arcs[j] = -1
                self.count -= 1
                removed += 1
        return removed

    def reverse(self):
        """Swap out_arcs and in_arcs in place; count unchanged."""
        self.out_arcs, self.in_arcs = self.in_arcs, self.out_arcs

    def extend(self, other):
        """Add every arc of other (an Arcs with the same n).

        Atomic: all arcs of other are pre-checked against self before any
        mutation, so a conflict raises ValueError with self unchanged.
        """
        if not isinstance(other, Arcs) or other.n != self.n:
            raise ValueError("extend requires an Arcs with the same n")
        pending = [(i, j) for i, j in enumerate(other.out_arcs) if j != -1]
        for i, j in pending:
            if self.out_arcs[i] != -1:
                raise ValueError("vertex %d already has an out-arc" % i)
            if self.in_arcs[j] != -1:
                raise ValueError("vertex %d already has an in-arc" % j)
            if self.out_arcs[j] == i:
                raise ValueError("reverse arc %d->%d already present" % (j, i))
        for i, j in pending:
            self.out_arcs[i] = j
            self.in_arcs[j] = i
        self.count += len(pending)

    def sources(self, vertices=None):
        """Sorted list of i with in_arcs[i] == -1 (isolated included).

        When vertices (an iterable of indices) is given, restrict to that
        set. Out-of-range indices raise ValueError.
        """
        if vertices is None:
            return [i for i in range(self.n) if self.in_arcs[i] == -1]
        wanted = set()
        for v in vertices:
            self._check_index(v)
            wanted.add(v)
        return sorted(i for i in wanted if self.in_arcs[i] == -1)

    def arcs(self):
        """List of (i, j) pairs sorted by tail i."""
        return [(i, j) for i, j in enumerate(self.out_arcs) if j != -1]

    def copy(self):
        """Independent copy (the entry lists are copied)."""
        new = Arcs(self.n)
        new.out_arcs = self.out_arcs[:]
        new.in_arcs = self.in_arcs[:]
        new.count = self.count
        return new

    def __len__(self):
        return self.count

    def __repr__(self):
        return "Arcs(n=%d, arcs=%r)" % (self.n, self.arcs())
