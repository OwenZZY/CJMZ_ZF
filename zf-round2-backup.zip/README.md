# zf-approx

A Python implementation of the zero-forcing approximation algorithm of
Cameron–Janssen–Mathew–Zhang, [*An approximation algorithm for zero
forcing*](https://arxiv.org/abs/2402.08866) (arXiv:2402.08866v1).

Given a graph and a nice path decomposition of width `w`, the algorithm
returns a zero forcing set `S` and a fort packing `F` with
`|S| ≤ (w + 1)·|F|`; with an optimal decomposition this is a
`(pw(G) + 1)`-approximation of the zero forcing number. It also returns
the forcing arc set `A` whose sources are exactly `S`.

Pure standard library, no dependencies.

## Quickstart

```python
from zf import Graph, NicePathDecomposition, zero_forcing_set

# Vertices are 0-based internally; external names are kept in a bijection.
graph = Graph({1, 2, 4}, [(1, 2), (2, 4)])      # names (1, 2, 4) <-> indices 0, 1, 2

# A nice path decomposition as ops: (vertex, +1 introduce / -1 forget).
pd = NicePathDecomposition([(0, +1), (1, +1), (0, -1), (2, +1), (1, -1), (2, -1)])

result = zero_forcing_set(graph, pd)
print(result.zf_set)          # zero forcing set, as indices
print(result.forts)           # disjoint forts (lower-bound certificate)
print(result.arcs.arcs())     # forcing arcs (u, v): "u forces v"
print([graph.names[i] for i in result.zf_set])   # back to external names
```

A runnable worked example: `python3 examples/demo.py`.

## Layout

| file | contents |
|---|---|
| `zf/graph.py` | `Graph`: static graph, 0-based indices, external-name bijection, edge list |
| `zf/arcs.py` | `Arcs`: forcing arc set (`out_arcs`/`in_arcs` arrays, add/delete/reverse/extend/sources) |
| `zf/decomposition.py` | `NicePathDecomposition`: bags as `(v, ±1)` ops, validation |
| `zf/closure.py` | `closure(graph, blue)`: zero forcing to fixation; returns white set and forcing arcs |
| `zf/algorithm.py` | `zero_forcing_set(graph, pd)`: the main loop (Algorithm 1, L1–L8) with its tricks |
| `SPEC-v1.md` | implementation specification: interfaces, loop, trick report |
| `docs/definitions.md` | mathematical definitions from the paper, one per line |
| `tests/` | unit tests plus brute-force cross-checks on small graphs |

## Tests

```sh
python3 -m unittest discover -s tests -v
```

The algorithm tests compare against an independent naive forcing simulator
and exact brute-force zero forcing numbers on graphs up to 10 vertices
(paths, cycles, complete graphs, stars, Petersen, grids, and hundreds of
random graphs with random decomposition orders).

## Notes

- The core assumes suitable inputs: `NicePathDecomposition.validate(graph)`
  checks the decomposition axioms (edge coverage, contiguity, empty end bags,
  one-vertex steps) and that every vertex lies in some bag.
- The paper's arXiv source is kept locally under `resources/` for reference
  only; please cite the [arXiv entry](https://arxiv.org/abs/2402.08866).