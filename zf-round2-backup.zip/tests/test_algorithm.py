"""Integration tests for zf.algorithm against independent brute force.

Run from the workspace root:
    python3 -m unittest discover -s tests -p "test_algorithm.py" -v
"""

from __future__ import annotations

import random
import unittest

from zf import Arcs, Graph, NicePathDecomposition, ZFResult, zero_forcing_set

from helpers import (
    arcs_force_all,
    brute_force_z,
    complete_edges,
    cycle_edges,
    grid_edges,
    is_fort,
    naive_white,
    nice_pd_ops,
    path_edges,
    petersen_edges,
    random_graph,
    random_order,
    star_edges,
)


def build(n, edges, order=None):
    graph = Graph(n, edges)
    if order is None:
        order = list(range(n))
    ops = nice_pd_ops(n, graph.adj, order)
    pd = NicePathDecomposition(ops, n=n)
    return graph, pd


class AlgorithmTests(unittest.TestCase):
    def check_invariants(self, graph, pd, res):
        """Every guarantee the paper makes about the output, checked."""
        n = graph.n
        self.assertIsInstance(res, ZFResult)
        # S is a zero forcing set (independent naive simulation).
        self.assertEqual(naive_white(n, graph.adj, res.zf_set), [])
        self.assertEqual(list(res.zf_set), sorted(set(res.zf_set)))
        # A is a forcing arc set representing a process from S.
        self.assertIsInstance(res.arcs, Arcs)
        self.assertEqual(res.arcs.sources(), list(res.zf_set))
        self.assertEqual(len(res.arcs), n - len(res.zf_set))
        pairs = res.arcs.arcs()
        self.assertTrue(arcs_force_all(n, graph.adj, pairs))
        # F is a fort packing: non-empty, pairwise disjoint forts.
        seen = set()
        for fort in res.forts:
            self.assertTrue(fort)
            self.assertTrue(is_fort(n, graph.adj, fort))
            self.assertFalse(seen & fort)
            seen |= fort
        # Size bounds: |F| <= Z(G) <= |S| <= (w+1)|F|.
        z = brute_force_z(n, graph.adj)
        self.assertLessEqual(len(res.forts), z)
        self.assertLessEqual(z, len(res.zf_set))
        self.assertLessEqual(len(res.zf_set), (pd.width + 1) * len(res.forts))
        return z

    def run_case(self, n, edges, order=None):
        graph, pd = build(n, edges, order)
        res = zero_forcing_set(graph, pd)
        self.check_invariants(graph, pd, res)
        return graph, pd, res

    # --- degenerate and tiny graphs -----------------------------------

    def test_empty_graph(self):
        graph, pd, res = self.run_case(0, [])
        self.assertEqual(res.zf_set, ())
        self.assertEqual(res.forts, ())
        self.assertEqual(len(res.arcs), 0)

    def test_single_vertex(self):
        _, _, res = self.run_case(1, [])
        self.assertEqual(res.zf_set, (0,))
        self.assertEqual(len(res.forts), 1)

    def test_two_vertices_no_edge(self):
        _, _, res = self.run_case(2, [])
        self.assertEqual(len(res.zf_set), 2)

    def test_two_vertices_edge(self):
        _, _, res = self.run_case(2, [(0, 1)])
        self.assertEqual(len(res.zf_set), 1)

    def test_edgeless_four(self):
        _, _, res = self.run_case(4, [])
        self.assertEqual(len(res.zf_set), 4)

    def test_disconnected_two_triangles(self):
        edges = [(0, 1), (1, 2), (0, 2), (3, 4), (4, 5), (3, 5)]
        self.run_case(6, edges)

    def test_disconnected_path_plus_isolated(self):
        self.run_case(5, [(0, 1), (1, 2)])

    # --- standard families ---------------------------------------------

    def test_paths(self):
        for n in range(2, 9):
            with self.subTest(n=n):
                _, _, res = self.run_case(n, path_edges(n))
                self.assertEqual(brute_force_z(n, Graph(n, path_edges(n)).adj), 1)

    def test_cycles(self):
        for n in range(3, 9):
            with self.subTest(n=n):
                self.run_case(n, cycle_edges(n))

    def test_complete_graphs(self):
        for n in range(2, 8):
            with self.subTest(n=n):
                _, _, res = self.run_case(n, complete_edges(n))
                self.assertEqual(len(res.zf_set), n - 1)  # Z(K_n) = n-1

    def test_stars(self):
        for k in range(2, 7):
            with self.subTest(k=k):
                _, _, res = self.run_case(k + 1, star_edges(k))
                self.assertEqual(len(res.zf_set), k - 1)  # Z(K_{1,k}) = k-1

    def test_petersen(self):
        graph, pd, res = self.run_case(10, petersen_edges())
        self.assertEqual(brute_force_z(10, graph.adj), 5)

    def test_grid_2x3(self):
        self.run_case(6, grid_edges(2, 3))

    def test_grid_2x4_random_orders(self):
        rng = random.Random(7)
        edges = grid_edges(2, 4)
        for _ in range(5):
            self.run_case(8, edges, random_order(8, rng))

    def test_house_graph(self):
        # triangle 0-1-2 on top of square 1-2-3-4
        self.run_case(5, [(0, 1), (0, 2), (1, 2), (1, 3), (2, 4), (3, 4)])

    # --- randomized cross-checks ---------------------------------------

    def test_random_small_graphs(self):
        rng = random.Random(20261120)
        trials = 0
        for n in range(2, 9):
            for p in (0.15, 0.35, 0.6, 0.85):
                for _ in range(10):
                    edges = random_graph(n, p, rng)
                    order = random_order(n, rng)
                    with self.subTest(n=n, p=p, edges=edges, order=order):
                        self.run_case(n, edges, order)
                    trials += 1
        self.assertEqual(trials, 280)

    def test_random_orders_fixed_graph(self):
        rng = random.Random(42)
        edges = petersen_edges()
        for _ in range(8):
            self.run_case(10, edges, random_order(10, rng))

    # --- interface behavior ---------------------------------------------

    def test_determinism(self):
        graph, pd = build(6, grid_edges(2, 3), [5, 0, 3, 1, 4, 2])
        r1 = zero_forcing_set(graph, pd)
        r2 = zero_forcing_set(graph, pd)
        self.assertEqual(r1.zf_set, r2.zf_set)
        self.assertEqual(r1.forts, r2.forts)
        self.assertEqual(r1.arcs.arcs(), r2.arcs.arcs())

    def test_validate_flag(self):
        graph, pd = build(4, path_edges(4))
        r1 = zero_forcing_set(graph, pd, validate=True)
        r2 = zero_forcing_set(graph, pd, validate=False)
        self.assertEqual(r1.zf_set, r2.zf_set)
        self.assertEqual(r1.forts, r2.forts)

    def test_unsuitable_pd_rejected(self):
        # PD covers only vertex 0 of a 2-vertex graph with an edge: D1 fails.
        graph = Graph(2, [(0, 1)])
        pd = NicePathDecomposition([(0, +1), (0, -1)], n=2)
        with self.assertRaises(ValueError):
            zero_forcing_set(graph, pd)

    def test_external_names(self):
        graph = Graph({1, 2, 4}, [(1, 2), (2, 4)])
        self.assertEqual(graph.names, (1, 2, 4))
        ops = nice_pd_ops(3, graph.adj, [0, 1, 2])
        pd = NicePathDecomposition(ops, n=3)
        res = zero_forcing_set(graph, pd)
        self.check_invariants(graph, pd, res)
        named = {graph.names[i] for i in res.zf_set}
        self.assertEqual(len(named), len(res.zf_set))

    def test_from_bags_input(self):
        bags = [frozenset(), frozenset({0}), frozenset({0, 1}),
                frozenset({1}), frozenset({1, 2}), frozenset({2}), frozenset()]
        pd = NicePathDecomposition.from_bags(bags)
        graph = Graph(3, path_edges(3))
        res = zero_forcing_set(graph, pd)
        self.check_invariants(graph, pd, res)


if __name__ == "__main__":
    unittest.main()