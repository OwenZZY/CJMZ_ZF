"""Tests for zf.closure: hand cases, arc validity, naive cross-check, regions.

Run from the workspace root:
    python3 -m unittest discover -s tests -p "test_forcing.py" -v
"""

import itertools
import random
import unittest

from zf.closure import closure


class G:  # test-only graph stand-in (zf/graph.py is owned by another agent)
    def __init__(self, n, edges):
        self.n = n
        adj = [[] for _ in range(n)]
        for a, b in edges:
            adj[a].append(b)
            adj[b].append(a)
        self.adj = tuple(sorted(t) for t in adj)


def naive_white(n, adj, blue):
    """Independent simulator: repeatedly scan ALL blue vertices in index
    order, force the first eligible one (unique white neighbor) found,
    restart the scan after each force, stop when a full scan finds no move.
    Return the sorted final white list.
    """
    is_blue = [False] * n
    for v in blue:
        is_blue[v] = True
    while True:
        moved = False
        for u in range(n):
            if not is_blue[u]:
                continue
            white_nbrs = [w for w in adj[u] if not is_blue[w]]
            if len(white_nbrs) == 1:
                is_blue[white_nbrs[0]] = True
                moved = True
                break
        if not moved:
            return [i for i in range(n) if not is_blue[i]]


def induced_adj(region, adj):
    """Adjacency of G[region], relabeled to 0..len(region)-1 (region sorted)."""
    region = sorted(region)
    pos = {v: i for i, v in enumerate(region)}
    return [tuple(sorted(pos[w] for w in adj[v] if w in pos)) for v in region]


def random_graph(rng, n, p=0.3):
    edges = [(a, b) for a in range(n) for b in range(a + 1, n)
             if rng.random() < p]
    return G(n, edges)


def check_arcs(tc, graph, initial_blue, white, arcs):
    """Validate arcs: edges, tail/head uniqueness, acyclicity, heads exactly
    the newly blue vertices, and replay of the color change rule in order."""
    n = graph.n
    adj = graph.adj
    tc.assertEqual(white, sorted(set(white)))
    edge_set = {(a, b) for a in range(n) for b in adj[a]}
    init = set(initial_blue)
    tails, heads = set(), set()
    out = {}
    for u, v in arcs:
        tc.assertIn((u, v), edge_set)
        tc.assertNotIn(u, tails)
        tc.assertNotIn(v, heads)
        tails.add(u)
        heads.add(v)
        out[u] = v
    # Following out-arcs from any vertex never revisits a vertex (no cycle).
    for start in range(n):
        seen = set()
        cur = start
        while cur in out:
            tc.assertNotIn(cur, seen)
            seen.add(cur)
            cur = out[cur]
    final_blue = set(range(n)) - set(white)
    tc.assertEqual(heads, final_blue - init)
    tc.assertEqual(set(white), set(range(n)) - (init | heads))
    # Replay the recorded forces: each must be legal at its moment.
    blue = set(init)
    for u, v in arcs:
        tc.assertIn(u, blue)
        tc.assertNotIn(v, blue)
        tc.assertEqual([w for w in adj[u] if w not in blue], [v])
        blue.add(v)
    tc.assertEqual(sorted(set(range(n)) - blue), white)


class HandCases(unittest.TestCase):
    def test_path(self):
        g = G(3, [(0, 1), (1, 2)])
        self.assertEqual(closure(g, [0]), ([], [(0, 1), (1, 2)]))
        # The middle vertex has TWO white neighbors, so it is stuck; the
        # naive simulator confirms white [0, 2] (not all blue).
        self.assertEqual(closure(g, [1]), ([0, 2], []))
        self.assertEqual(naive_white(3, g.adj, [1]), [0, 2])
        self.assertEqual(closure(g, []), ([0, 1, 2], []))
        self.assertEqual(closure(g, [0, 2]), ([], [(0, 1)]))
        self.assertEqual(closure(g, [0, 1, 2]), ([], []))

    def test_canon_smallest_eligible(self):
        # P4 from {0,3}: both endpoints eligible; the smallest index (0)
        # forces first, then 1 forces 2 (chain 0->1->2, vertex 3 idle).
        # A FIFO queue would give [(0,1),(3,2)] instead — this pins the
        # min-index canon (tex:L621), matching the parallel project.
        g = G(4, [(0, 1), (1, 2), (2, 3)])
        self.assertEqual(closure(g, [0, 3]), ([], [(0, 1), (1, 2)]))
        self.assertEqual(closure(g, [3, 0]), ([], [(0, 1), (1, 2)]))

    def test_star(self):
        g = G(4, [(0, 1), (0, 2), (0, 3)])
        # A leaf forces the center, the center forces the last leaf.
        self.assertEqual(closure(g, [1, 2]), ([], [(1, 0), (0, 3)]))
        # Center with 3 white neighbors is stuck.
        self.assertEqual(closure(g, [0]), ([1, 2, 3], []))
        self.assertEqual(closure(g, [1]), ([2, 3], [(1, 0)]))

    def test_cycle_c4(self):
        g = G(4, [(0, 1), (1, 2), (2, 3), (3, 0)])
        self.assertEqual(closure(g, [0, 1]), ([], [(0, 3), (1, 2)]))
        self.assertEqual(closure(g, [0]), ([1, 2, 3], []))

    def test_complete_k4(self):
        edges = [(a, b) for a in range(4) for b in range(a + 1, 4)]
        g = G(4, edges)
        for pair in itertools.combinations(range(4), 2):
            white, arcs = closure(g, pair)
            self.assertEqual(white, sorted(set(range(4)) - set(pair)))
            self.assertEqual(arcs, [])
        for triple in itertools.combinations(range(4), 3):
            missing = (set(range(4)) - set(triple)).pop()
            white, arcs = closure(g, triple)
            self.assertEqual(white, [])
            self.assertEqual(arcs, [(min(triple), missing)])

    def test_isolated(self):
        g = G(3, [(0, 1)])  # vertex 2 isolated
        self.assertEqual(closure(g, [2]), ([0, 1], []))
        self.assertEqual(closure(g, [0]), ([2], [(0, 1)]))
        self.assertEqual(closure(g, [0, 2]), ([], [(0, 1)]))
        self.assertEqual(closure(G(1, []), [0]), ([], []))
        self.assertEqual(closure(G(1, []), []), ([0], []))

    def test_n0(self):
        self.assertEqual(closure(G(0, []), []), ([], []))

    def test_empty_blue(self):
        graphs = [G(3, [(0, 1), (1, 2)]), G(4, [(0, 1), (0, 2), (0, 3)]),
                  G(5, [])]
        for g in graphs:
            self.assertEqual(closure(g, []), (list(range(g.n)), []))

    def test_all_blue(self):
        graphs = [G(3, [(0, 1), (1, 2)]), G(4, [(0, 1), (0, 2), (0, 3)]),
                  G(5, [])]
        for g in graphs:
            self.assertEqual(closure(g, range(g.n)), ([], []))

    def test_duplicates_and_iterables(self):
        g = G(3, [(0, 1), (1, 2)])
        expected = ([], [(0, 1), (1, 2)])
        self.assertEqual(closure(g, [0, 0, 0]), expected)
        self.assertEqual(closure(g, iter([0, 0])), expected)
        self.assertEqual(closure(g, (v for v in [0, 0])), expected)
        self.assertEqual(closure(g, {0}), expected)
        self.assertEqual(closure(g, frozenset([0])), expected)

    def test_invalid_blue(self):
        g = G(3, [(0, 1), (1, 2)])
        with self.assertRaises(ValueError):
            closure(g, [3])
        with self.assertRaises(ValueError):
            closure(g, [-1])

    def test_determinism(self):
        rng = random.Random(7)
        cases = [(G(3, [(0, 1), (1, 2)]), [0]),
                 (G(4, [(0, 1), (0, 2), (0, 3)]), [1, 2]),
                 (G(4, [(0, 1), (1, 2), (2, 3), (3, 0)]), [0, 1])]
        for _ in range(50):
            g = random_graph(rng, rng.randint(1, 9))
            cases.append((g, [v for v in range(g.n) if rng.random() < 0.5]))
        for g, blue in cases:
            snapshot = list(blue)
            first = closure(g, blue)
            for _ in range(3):
                self.assertEqual(closure(g, blue), first)
            self.assertEqual(closure(g, iter(blue)), first)
            self.assertEqual(closure(g, set(blue)), first)
            self.assertEqual(blue, snapshot)  # input not mutated


class RandomCrossCheck(unittest.TestCase):
    def test_random_arc_validity_and_naive(self):
        rng = random.Random(240208866)
        for _ in range(400):  # >= 300 trials required
            n = rng.randint(1, 9)
            g = random_graph(rng, n)
            blue = [v for v in range(n) if rng.random() < 0.5]
            white, arcs = closure(g, blue)
            check_arcs(self, g, blue, white, arcs)
            # Order-independence of the white set: naive uses a different
            # move order (index scan with restart) than the min-heap canon.
            self.assertEqual(white, naive_white(n, g.adj, blue))
            self.assertEqual(closure(g, blue), (white, arcs))


class RegionOutsideBlue(unittest.TestCase):
    """[L6c] scenario: closure on the full graph with outside vertices
    pre-blued vs naive forcing on the induced region.

    Full equivalence (and all arcs inside the region) holds when every
    region-neighbor of every outside vertex is initially blue — the boundary
    condition guaranteed by contiguity in the main algorithm (SPEC-v1 §5.4).
    Without it, an outside vertex with a unique white region-neighbor forces
    into the region; then only the one-sided inclusion holds.
    """

    def check_region(self, g, region, blue):
        """Assert the region comparison; return True iff the boundary
        condition held and full equivalence + inside-region arcs were checked."""
        region = set(region)
        blue = set(blue)
        outside = set(range(g.n)) - region
        boundary_ok = all(
            all(w in blue for w in g.adj[u] if w in region) for u in outside)
        white, arcs = closure(g, outside | blue)
        rlist = sorted(region)
        pos = {v: i for i, v in enumerate(rlist)}
        iadj = induced_adj(rlist, g.adj)
        naive = {rlist[i] for i in
                 naive_white(len(rlist), iadj, [pos[v] for v in blue])}
        inside = set(white) & region
        if boundary_ok:
            self.assertEqual(inside, naive)
            for u, v in arcs:
                self.assertIn(u, region)
                self.assertIn(v, region)
        else:
            # Always true: full-graph forcing can only blue MORE inside.
            self.assertTrue(inside <= naive)
        return boundary_ok

    def test_path_six_literal(self):
        # Region {1,2,3}, inside blue {1}, outside {0,4,5} pre-blued.
        # Naive on the induced path 1-2-3 from {1}: 1 forces 2, 2 forces 3,
        # so the correct expectation is white == [] (not [3]).
        g = G(6, [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5)])
        region = {1, 2, 3}
        iadj = induced_adj(sorted(region), g.adj)
        self.assertEqual(naive_white(3, iadj, [0]), [])  # 1 relabeled to 0
        white, arcs = closure(g, [0, 1, 4, 5])
        self.assertEqual(white, [])
        self.assertEqual(set(white) & region, set())
        # Min-index canon: 1 forces 2, then 2 (smaller than 4) forces 3
        # before outside vertex 4 pops; 4's heap entry goes stale.
        self.assertEqual(arcs, [(1, 2), (2, 3)])
        # The boundary condition fails here (outside 4 has the unique white
        # neighbor 3 inside the region). With no inside blue, an outside
        # vertex DOES force into the region — pinning that semantics.
        white, arcs = closure(g, [0, 4, 5])
        self.assertEqual(white, [])
        self.assertEqual(arcs, [(0, 1), (1, 2), (2, 3)])
        self.assertEqual(naive_white(3, iadj, []), [0, 1, 2])

    def test_path_six_boundary_respecting(self):
        g = G(6, [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5)])
        region = {1, 2, 3}
        # Inside blue {1, 3}: every region-neighbor of an outside vertex is
        # blue, as contiguity guarantees in the main algorithm.
        self.assertTrue(self.check_region(g, region, {1, 3}))
        white, arcs = closure(g, [0, 1, 3, 4, 5])
        self.assertEqual(white, [])
        self.assertEqual(arcs, [(1, 2)])

    def test_boundary_counterexample(self):
        # Path 0-1-2, region {2}, no inside blue: outside vertex 1 has the
        # unique white neighbor 2 and forces it. Pins down the semantics
        # when the boundary condition fails.
        g = G(3, [(0, 1), (1, 2)])
        white, arcs = closure(g, [0, 1])
        self.assertEqual(white, [])
        self.assertEqual(arcs, [(1, 2)])
        self.assertEqual(naive_white(1, induced_adj([2], g.adj), []), [0])
        self.assertFalse(self.check_region(g, {2}, set()))

    def test_random_regions(self):
        rng = random.Random(88662402)
        full_checks = 0
        for _ in range(300):
            n = rng.randint(1, 9)
            g = random_graph(rng, n)
            region = {v for v in range(n) if rng.random() < 0.5}
            blue = {v for v in region if rng.random() < 0.5}
            if self.check_region(g, region, blue):
                full_checks += 1
            # Boundary-saturated blue: always satisfies the condition, so
            # full equivalence and inside-region arcs are always asserted.
            outside = set(range(n)) - region
            boundary = {v for v in region
                        if any(w in outside for w in g.adj[v])}
            blue2 = boundary | {v for v in region - boundary
                                if rng.random() < 0.5}
            self.assertTrue(self.check_region(g, region, blue2))
            full_checks += 1
        self.assertGreaterEqual(full_checks, 100)


if __name__ == "__main__":
    unittest.main()
