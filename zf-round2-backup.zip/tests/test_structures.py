"""Tests for zf.graph, zf.arcs and zf.decomposition (stdlib unittest)."""

import random
import types
import unittest

from zf.arcs import Arcs
from zf.decomposition import NicePathDecomposition
from zf.graph import Graph

# Nice path decomposition of the path 0-1-2.
PATH_OPS = [(0, 1), (1, 1), (0, -1), (2, 1), (1, -1), (2, -1)]
PATH_BAGS = (
    frozenset(),
    frozenset({0}),
    frozenset({0, 1}),
    frozenset({1}),
    frozenset({1, 2}),
    frozenset({2}),
    frozenset(),
)


def assert_arc_invariant(test, a):
    """out_arcs[i] == j iff in_arcs[j] == i; count consistent; no 2-cycles."""
    n = a.n
    test.assertEqual(len(a.out_arcs), n)
    test.assertEqual(len(a.in_arcs), n)
    out_count = 0
    for i in range(n):
        j = a.out_arcs[i]
        test.assertTrue(j == -1 or 0 <= j < n)
        if j != -1:
            test.assertNotEqual(i, j)
            test.assertEqual(a.in_arcs[j], i)
            test.assertNotEqual(a.out_arcs[j], i)  # no two-way pair
            out_count += 1
    in_count = 0
    for j in range(n):
        i = a.in_arcs[j]
        test.assertTrue(i == -1 or 0 <= i < n)
        if i != -1:
            test.assertEqual(a.out_arcs[i], j)
            in_count += 1
    test.assertEqual(out_count, in_count)
    test.assertEqual(a.count, out_count)
    test.assertEqual(len(a), out_count)
    test.assertEqual(len(a.arcs()), out_count)


class TestGraph(unittest.TestCase):
    def test_name_bijection_example(self):
        g = Graph({1, 2, 4}, [(1, 2), (2, 4)])
        self.assertEqual(g.n, 3)
        self.assertEqual(g.names, (1, 2, 4))
        self.assertEqual(g.index, {1: 0, 2: 1, 4: 2})
        for i, name in enumerate(g.names):
            self.assertEqual(g.index[name], i)
        self.assertEqual(g.edges, ((0, 1), (1, 2)))
        self.assertEqual(g.adj, ((1,), (0, 2), (1,)))
        self.assertEqual(len(g), 3)

    def test_name_bijection_strings(self):
        g = Graph({"c", "a", "b"}, [("b", "a"), ("c", "b")])
        self.assertEqual(g.names, ("a", "b", "c"))
        self.assertEqual(g.index, {"a": 0, "b": 1, "c": 2})
        self.assertEqual(g.edges, ((0, 1), (1, 2)))

    def test_int_form(self):
        g = Graph(3, [(0, 1), (1, 2)])
        self.assertEqual(g.n, 3)
        self.assertEqual(g.names, (0, 1, 2))
        self.assertEqual(g.index, {0: 0, 1: 1, 2: 2})
        self.assertEqual(g.edges, ((0, 1), (1, 2)))
        self.assertEqual(g.adj, ((1,), (0, 2), (1,)))

    def test_edges_normalized_and_sorted(self):
        g = Graph(4, [(3, 2), (1, 0), (3, 1)])
        self.assertEqual(g.edges, ((0, 1), (1, 3), (2, 3)))
        self.assertEqual(g.adj, ((1,), (0, 3), (3,), (1, 2)))

    def test_edges_from_generator(self):
        g = Graph(3, ((i, i + 1) for i in range(2)))
        self.assertEqual(g.edges, ((0, 1), (1, 2)))

    def test_isolated_vertices_in_adj(self):
        g = Graph(4, [(0, 2)])
        self.assertEqual(g.adj, ((2,), (), (0,), ()))

    def test_loop_raises(self):
        with self.assertRaises(ValueError):
            Graph(3, [(1, 1)])
        with self.assertRaises(ValueError):
            Graph({1, 2}, [(2, 2)])

    def test_duplicate_edge_raises(self):
        with self.assertRaises(ValueError):
            Graph(3, [(0, 1), (1, 0)])
        with self.assertRaises(ValueError):
            Graph(3, [(0, 1), (0, 1)])
        with self.assertRaises(ValueError):
            Graph({1, 2, 3}, [(1, 2), (2, 1)])

    def test_unknown_endpoint_raises(self):
        with self.assertRaises(ValueError):
            Graph(3, [(0, 3)])
        with self.assertRaises(ValueError):
            Graph(3, [(-1, 0)])
        with self.assertRaises(ValueError):
            Graph(3, [(0, 1.5)])
        with self.assertRaises(ValueError):
            Graph({1, 2}, [(1, 3)])

    def test_duplicate_vertex_names_raise(self):
        with self.assertRaises(ValueError):
            Graph([2, 1, 2], [])

    def test_unhashable_vertex_names_raise(self):
        with self.assertRaises(ValueError):
            Graph([[1], [2]], [])

    def test_malformed_edge_pair_raises(self):
        with self.assertRaises(ValueError):
            Graph(3, [(0, 1, 2)])
        with self.assertRaises(ValueError):
            Graph(3, [(0,)])
        with self.assertRaises(ValueError):
            Graph(3, [0])

    def test_empty_graph(self):
        for g in (Graph(0, []), Graph([], [])):
            self.assertEqual(g.n, 0)
            self.assertEqual(g.names, ())
            self.assertEqual(g.index, {})
            self.assertEqual(g.edges, ())
            self.assertEqual(g.adj, ())
            self.assertEqual(len(g), 0)

    def test_negative_vertex_count_raises(self):
        with self.assertRaises(ValueError):
            Graph(-1, [])

    def test_len(self):
        self.assertEqual(len(Graph(5, [])), 5)
        self.assertEqual(len(Graph({1, 2, 4}, [])), 3)

    def test_no_mutators(self):
        g = Graph(3, [(0, 1)])
        for name in ("add_edge", "remove_edge", "add_vertex",
                     "remove_vertex", "add", "remove"):
            self.assertFalse(hasattr(g, name))


class TestArcs(unittest.TestCase):
    def test_initial_state(self):
        a = Arcs(4)
        self.assertEqual(a.n, 4)
        self.assertEqual(a.out_arcs, [-1, -1, -1, -1])
        self.assertEqual(a.in_arcs, [-1, -1, -1, -1])
        self.assertEqual(a.count, 0)
        self.assertEqual(len(a), 0)
        self.assertEqual(a.arcs(), [])
        self.assertEqual(a.sources(), [0, 1, 2, 3])
        assert_arc_invariant(self, a)

    def test_zero_n(self):
        a = Arcs(0)
        assert_arc_invariant(self, a)
        self.assertEqual(a.sources(), [])
        self.assertEqual(a.arcs(), [])
        a.reverse()
        a.extend(Arcs(0))
        self.assertEqual(a.count, 0)
        with self.assertRaises(ValueError):
            a.add(0, 0)

    def test_add_chain_invariant(self):
        a = Arcs(5)
        a.add(0, 1)
        a.add(1, 2)
        a.add(2, 3)
        self.assertEqual(a.out_arcs, [1, 2, 3, -1, -1])
        self.assertEqual(a.in_arcs, [-1, 0, 1, 2, -1])
        self.assertEqual(a.count, 3)
        self.assertEqual(len(a), 3)
        self.assertEqual(a.arcs(), [(0, 1), (1, 2), (2, 3)])
        self.assertEqual(a.sources(), [0, 4])
        assert_arc_invariant(self, a)

    def test_add_occupied_tail_raises(self):
        a = Arcs(3)
        a.add(0, 1)
        with self.assertRaises(ValueError):
            a.add(0, 2)

    def test_add_occupied_head_raises(self):
        a = Arcs(3)
        a.add(0, 1)
        with self.assertRaises(ValueError):
            a.add(2, 1)

    def test_add_self_loop_raises(self):
        a = Arcs(3)
        with self.assertRaises(ValueError):
            a.add(1, 1)

    def test_add_reverse_arc_raises(self):
        a = Arcs(3)
        a.add(0, 1)
        with self.assertRaises(ValueError):
            a.add(1, 0)

    def test_add_out_of_range_raises(self):
        a = Arcs(3)
        for i, j in ((-1, 0), (0, -1), (3, 0), (0, 3), (3, 3)):
            with self.subTest(i=i, j=j):
                with self.assertRaises(ValueError):
                    a.add(i, j)

    def test_failed_add_leaves_state_unchanged(self):
        a = Arcs(3)
        a.add(0, 1)
        before = (a.out_arcs[:], a.in_arcs[:], a.count)
        for i, j in ((0, 2), (2, 1), (1, 0), (1, 1), (-1, 0), (0, 3)):
            with self.subTest(i=i, j=j):
                with self.assertRaises(ValueError):
                    a.add(i, j)
                self.assertEqual((a.out_arcs, a.in_arcs, a.count), before)

    def test_delete_single_head(self):
        a = Arcs(3)
        a.add(0, 1)
        a.add(1, 2)
        self.assertEqual(a.delete(1), 1)  # removes 0->1, whose head is 1
        self.assertEqual(a.out_arcs, [-1, 2, -1])
        self.assertEqual(a.in_arcs, [-1, -1, 1])
        self.assertEqual(a.count, 1)
        self.assertEqual(a.arcs(), [(1, 2)])
        assert_arc_invariant(self, a)

    def test_delete_multiple_heads(self):
        a = Arcs(4)
        a.add(0, 1)
        a.add(1, 2)
        a.add(2, 3)
        self.assertEqual(a.delete([1, 3]), 2)
        self.assertEqual(a.arcs(), [(1, 2)])
        self.assertEqual(a.count, 1)
        self.assertEqual(a.delete([2]), 1)
        self.assertEqual(a.count, 0)
        assert_arc_invariant(self, a)

    def test_delete_generator_of_heads(self):
        a = Arcs(3)
        a.add(0, 1)
        a.add(1, 2)
        self.assertEqual(a.delete(j for j in (1, 2)), 2)
        self.assertEqual(a.count, 0)

    def test_delete_heads_without_in_arc(self):
        a = Arcs(3)
        a.add(0, 1)
        before = (a.out_arcs[:], a.in_arcs[:], a.count)
        self.assertEqual(a.delete(0), 0)
        self.assertEqual(a.delete([0, 2]), 0)
        self.assertEqual(a.delete([]), 0)
        self.assertEqual((a.out_arcs, a.in_arcs, a.count), before)
        self.assertEqual(a.delete(1), 1)
        self.assertEqual(a.count, 0)

    def test_delete_out_of_range_raises(self):
        a = Arcs(3)
        with self.assertRaises(ValueError):
            a.delete(3)
        with self.assertRaises(ValueError):
            a.delete(-1)
        with self.assertRaises(ValueError):
            a.delete([0, 3])

    def test_reverse_swaps_and_preserves_count(self):
        a = Arcs(4)
        a.add(0, 1)
        a.add(1, 2)
        out_before = a.out_arcs[:]
        in_before = a.in_arcs[:]
        a.reverse()
        self.assertEqual(a.out_arcs, in_before)
        self.assertEqual(a.in_arcs, out_before)
        self.assertEqual(a.count, 2)
        self.assertEqual(a.arcs(), [(1, 0), (2, 1)])
        self.assertEqual(a.sources(), [2, 3])
        assert_arc_invariant(self, a)

    def test_double_reverse_is_identity(self):
        a = Arcs(4)
        a.add(0, 1)
        a.add(1, 2)
        out_before = a.out_arcs[:]
        in_before = a.in_arcs[:]
        a.reverse()
        a.reverse()
        self.assertEqual(a.out_arcs, out_before)
        self.assertEqual(a.in_arcs, in_before)
        self.assertEqual(a.count, 2)

    def test_reverse_empty(self):
        a = Arcs(3)
        a.reverse()
        self.assertEqual(a.out_arcs, [-1, -1, -1])
        self.assertEqual(a.in_arcs, [-1, -1, -1])
        self.assertEqual(a.count, 0)

    def test_extend_disjoint(self):
        a = Arcs(4)
        a.add(0, 1)
        b = Arcs(4)
        b.add(2, 3)
        a.extend(b)
        self.assertEqual(a.arcs(), [(0, 1), (2, 3)])
        self.assertEqual(a.count, 2)
        self.assertEqual(b.count, 1)  # other unchanged
        assert_arc_invariant(self, a)

    def test_extend_joins_chains(self):
        a = Arcs(3)
        a.add(0, 1)
        b = Arcs(3)
        b.add(1, 2)
        a.extend(b)
        self.assertEqual(a.arcs(), [(0, 1), (1, 2)])
        self.assertEqual(a.count, 2)
        assert_arc_invariant(self, a)

    def test_extend_empty_other(self):
        a = Arcs(3)
        a.add(0, 1)
        a.extend(Arcs(3))
        self.assertEqual(a.count, 1)
        self.assertEqual(a.arcs(), [(0, 1)])

    def test_extend_atomic_on_conflict(self):
        def build(arcs, n=4):
            a = Arcs(n)
            for i, j in arcs:
                a.add(i, j)
            return a

        cases = {
            "occupied tail": ([(0, 1)], [(0, 2)]),
            "occupied head": ([(0, 1)], [(2, 1)]),
            "reverse arc": ([(0, 1)], [(1, 0)]),
            "same arc": ([(0, 1)], [(0, 1)]),
            # first arc of other fits, second conflicts: nothing applied
            "partial conflict": ([(3, 2)], [(0, 1), (2, 3)]),
        }
        for label, (a_arcs, b_arcs) in cases.items():
            with self.subTest(case=label):
                a = build(a_arcs)
                b = build(b_arcs)
                before = (a.out_arcs[:], a.in_arcs[:], a.count)
                with self.assertRaises(ValueError):
                    a.extend(b)
                self.assertEqual((a.out_arcs, a.in_arcs, a.count), before)

    def test_extend_wrong_n_raises(self):
        with self.assertRaises(ValueError):
            Arcs(3).extend(Arcs(4))

    def test_extend_non_arcs_raises(self):
        with self.assertRaises(ValueError):
            Arcs(3).extend([(0, 1)])
        with self.assertRaises(ValueError):
            Arcs(3).extend(None)

    def test_sources_full_and_restricted(self):
        a = Arcs(5)
        a.add(0, 1)
        a.add(2, 3)
        self.assertEqual(a.sources(), [0, 2, 4])  # isolated 4 included
        self.assertEqual(a.sources([4, 0, 2]), [0, 2, 4])
        self.assertEqual(a.sources([1, 3]), [])
        self.assertEqual(a.sources([]), [])
        self.assertEqual(a.sources(iter([2, 4])), [2, 4])
        self.assertEqual(a.sources([2, 2, 4]), [2, 4])

    def test_sources_out_of_range_raises(self):
        a = Arcs(3)
        with self.assertRaises(ValueError):
            a.sources([0, 3])
        with self.assertRaises(ValueError):
            a.sources([-1])

    def test_arcs_sorted_by_tail(self):
        a = Arcs(5)
        a.add(3, 4)
        a.add(0, 1)
        a.add(1, 2)
        self.assertEqual(a.arcs(), [(0, 1), (1, 2), (3, 4)])

    def test_copy_independence(self):
        a = Arcs(4)
        a.add(0, 1)
        b = a.copy()
        self.assertIsNot(a, b)
        self.assertIsNot(a.out_arcs, b.out_arcs)
        self.assertIsNot(a.in_arcs, b.in_arcs)
        self.assertEqual(b.arcs(), [(0, 1)])
        self.assertEqual(b.count, 1)
        b.add(1, 2)
        self.assertEqual(a.out_arcs[1], -1)
        self.assertEqual(a.count, 1)
        a.add(2, 3)
        self.assertEqual(b.out_arcs[2], -1)
        self.assertEqual(b.count, 2)
        b.delete(1)
        self.assertEqual(a.in_arcs[1], 0)
        assert_arc_invariant(self, a)
        assert_arc_invariant(self, b)

    def test_randomized_operations(self):
        rng = random.Random(240208866)
        n = 8
        a = Arcs(n)
        for step in range(600):
            op = rng.randrange(5)
            if op in (0, 1):
                i, j = rng.randrange(n), rng.randrange(n)
                before = (a.out_arcs[:], a.in_arcs[:], a.count)
                try:
                    a.add(i, j)
                except ValueError:
                    self.assertEqual(
                        (a.out_arcs, a.in_arcs, a.count), before,
                        "failed add mutated state at step %d" % step)
            elif op == 2:
                heads = [rng.randrange(n) for _ in range(rng.randrange(n + 1))]
                expected = len({j for j in heads if a.in_arcs[j] != -1})
                self.assertEqual(a.delete(heads), expected,
                                 "delete count at step %d" % step)
            elif op == 3:
                out_before, in_before = a.out_arcs[:], a.in_arcs[:]
                count_before = a.count
                a.reverse()
                self.assertEqual(a.out_arcs, in_before)
                self.assertEqual(a.in_arcs, out_before)
                self.assertEqual(a.count, count_before)
            else:
                b = Arcs(n)
                for _ in range(rng.randrange(n + 1)):
                    try:
                        b.add(rng.randrange(n), rng.randrange(n))
                    except ValueError:
                        pass
                before = (a.out_arcs[:], a.in_arcs[:], a.count)
                try:
                    a.extend(b)
                except ValueError:
                    self.assertEqual(
                        (a.out_arcs, a.in_arcs, a.count), before,
                        "failed extend mutated state at step %d" % step)
                else:
                    self.assertEqual(a.count, before[2] + b.count)
                    for i, j in b.arcs():
                        self.assertEqual(a.out_arcs[i], j)
            assert_arc_invariant(self, a)
            self.assertEqual(
                a.sources(), [i for i in range(n) if a.in_arcs[i] == -1])


class TestNicePathDecomposition(unittest.TestCase):
    def test_path_example_fields(self):
        pd = NicePathDecomposition(PATH_OPS)
        self.assertEqual(pd.ops, tuple(PATH_OPS))
        self.assertEqual(pd.bags, PATH_BAGS)
        self.assertEqual(pd.n, 3)
        self.assertEqual(pd.k, 5)
        self.assertEqual(pd.width, 1)
        self.assertEqual(len(pd.bags), len(pd.ops) + 1)

    def test_bags_are_frozensets(self):
        pd = NicePathDecomposition(PATH_OPS)
        for bag in pd.bags:
            self.assertIsInstance(bag, frozenset)

    def test_signs_normalized_to_int(self):
        pd = NicePathDecomposition([(0, 1.0), (0, -1.0)])
        self.assertEqual(pd.ops, ((0, 1), (0, -1)))
        for _, sign in pd.ops:
            self.assertIs(type(sign), int)
        pd = NicePathDecomposition([(0, True), (0, -1)])
        self.assertEqual(pd.ops, ((0, 1), (0, -1)))

    def test_bad_sign_raises(self):
        for sign in (0, 2, -2, 1.5, "+1", None):
            with self.subTest(sign=sign):
                with self.assertRaises(ValueError):
                    NicePathDecomposition([(0, sign), (0, -1)])

    def test_readd_raises(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1), (0, 1), (0, -1), (0, -1)])

    def test_remove_absent_raises(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, -1)])
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1), (1, -1)])

    def test_empty_intermediate_bag_raises(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1), (0, -1), (1, 1), (1, -1)])

    def test_nonempty_final_bag_raises(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1)])
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1), (1, 1), (0, -1)])

    def test_n_inference(self):
        self.assertEqual(NicePathDecomposition(PATH_OPS).n, 3)
        self.assertEqual(NicePathDecomposition([(2, 1), (2, -1)]).n, 3)
        self.assertEqual(NicePathDecomposition([(0, 1), (0, -1)]).n, 1)

    def test_explicit_n(self):
        pd = NicePathDecomposition([(0, 1), (0, -1)], n=5)
        self.assertEqual(pd.n, 5)
        self.assertEqual(pd.bags, (frozenset(), frozenset({0}), frozenset()))
        self.assertEqual(pd.k, 1)
        self.assertEqual(pd.width, 0)

    def test_vertex_out_of_range_raises(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition([(2, 1), (2, -1)], n=2)
        with self.assertRaises(ValueError):
            NicePathDecomposition([(-1, 1), (-1, -1)])
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1), (0, -1)], n=-1)
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 1), (0, -1)], n="3")

    def test_empty_ops(self):
        pd = NicePathDecomposition([])
        self.assertEqual(pd.ops, ())
        self.assertEqual(pd.bags, (frozenset(),))
        self.assertEqual(pd.n, 0)
        self.assertEqual(pd.k, -1)
        self.assertEqual(pd.width, -1)

    def test_empty_ops_with_explicit_n(self):
        pd = NicePathDecomposition([], n=4)
        self.assertEqual(pd.n, 4)
        self.assertEqual(pd.k, -1)
        self.assertEqual(pd.width, -1)
        self.assertEqual(pd.bags, (frozenset(),))

    def test_check_false_materializes_invalid_structure(self):
        pd = NicePathDecomposition(
            [(0, 1), (0, -1), (1, 1), (1, -1)], check=False)
        self.assertEqual(
            pd.bags,
            (frozenset(), frozenset({0}), frozenset(),
             frozenset({1}), frozenset()))
        self.assertEqual(pd.n, 2)
        self.assertEqual(pd.k, 3)
        self.assertEqual(pd.width, 0)
        # re-add / remove-absent are idempotent when unchecked
        pd = NicePathDecomposition(
            [(0, 1), (0, 1), (0, -1), (0, -1)], check=False)
        self.assertEqual(
            pd.bags,
            (frozenset(), frozenset({0}), frozenset({0}),
             frozenset(), frozenset()))
        # range checks are skipped too
        pd = NicePathDecomposition([(5, 1), (5, -1)], n=2, check=False)
        self.assertEqual(pd.bags[1], frozenset({5}))

    def test_check_false_rejects_unreplayable_sign(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition([(0, 0), (0, -1)], check=False)

    def test_from_bags_roundtrip(self):
        pd = NicePathDecomposition(PATH_OPS)
        pd2 = NicePathDecomposition.from_bags(pd.bags)
        self.assertEqual(pd2.ops, pd.ops)
        self.assertEqual(pd2.bags, pd.bags)
        self.assertEqual(pd2.n, pd.n)
        self.assertEqual(pd2.k, pd.k)
        self.assertEqual(pd2.width, pd.width)

    def test_from_bags_accepts_sets_and_lists(self):
        pd = NicePathDecomposition.from_bags(
            [[], [0], [0, 1], [1], [1, 2], [2], []])
        self.assertEqual(pd.ops, tuple(PATH_OPS))
        self.assertEqual(pd.bags, PATH_BAGS)
        pd = NicePathDecomposition.from_bags(
            [set(), {0}, {0, 1}, {1}, {1, 2}, {2}, set()])
        self.assertEqual(pd.ops, tuple(PATH_OPS))

    def test_from_bags_single_empty_bag(self):
        pd = NicePathDecomposition.from_bags([frozenset()])
        self.assertEqual(pd.ops, ())
        self.assertEqual(pd.n, 0)
        self.assertEqual(pd.k, -1)
        self.assertEqual(pd.width, -1)
        self.assertEqual(pd.bags, (frozenset(),))

    def test_from_bags_sparse_vertices(self):
        pd = NicePathDecomposition.from_bags([frozenset(), {2}, frozenset()])
        self.assertEqual(pd.n, 3)
        self.assertEqual(pd.ops, ((2, 1), (2, -1)))

    def test_from_bags_error_cases(self):
        cases = {
            "first non-empty": [{0}, frozenset()],
            "last non-empty": [frozenset(), {0}],
            "single non-empty": [{0}],
            "diff two": [frozenset(), {0, 1}, frozenset()],
            "diff zero": [frozenset(), frozenset()],
            "empty intermediate":
                [frozenset(), {0}, frozenset(), {1}, frozenset()],
        }
        for label, bags in cases.items():
            with self.subTest(case=label):
                with self.assertRaises(ValueError):
                    NicePathDecomposition.from_bags(bags)

    def test_from_bags_empty_sequence_raises(self):
        with self.assertRaises(ValueError):
            NicePathDecomposition.from_bags([])

    def test_validate_path_graph(self):
        pd = NicePathDecomposition(PATH_OPS)
        self.assertIsNone(pd.validate(Graph(3, [(0, 1), (1, 2)])))

    def test_validate_complete_graph_k4(self):
        ops = [(v, 1) for v in range(4)] + [(v, -1) for v in range(4)]
        pd = NicePathDecomposition(ops)
        self.assertEqual(pd.k, 7)
        self.assertEqual(pd.width, 3)
        edges = [(i, j) for i in range(4) for j in range(i + 1, 4)]
        self.assertIsNone(pd.validate(Graph(4, edges)))

    def test_validate_uncovered_edge_raises(self):
        pd = NicePathDecomposition(PATH_OPS)
        with self.assertRaises(ValueError):
            pd.validate(Graph(3, [(0, 2)]))
        with self.assertRaises(ValueError):
            pd.validate(Graph(3, [(0, 1), (0, 2)]))

    def test_validate_missing_vertex_raises(self):
        # explicit n=2 isolates the coverage check: vertex 1 in no bag
        pd = NicePathDecomposition([(0, 1), (0, -1)], n=2)
        with self.assertRaises(ValueError):
            pd.validate(Graph(2, []))
        # contract's literal example (inferred n=1) also fails, on n match
        pd = NicePathDecomposition([(0, 1), (0, -1)])
        with self.assertRaises(ValueError):
            pd.validate(Graph(2, []))

    def test_validate_n_mismatch_raises(self):
        pd = NicePathDecomposition(PATH_OPS)
        with self.assertRaises(ValueError):
            pd.validate(Graph(4, []))
        with self.assertRaises(ValueError):
            pd.validate(Graph(2, [(0, 1)]))

    def test_validate_empty_graph(self):
        self.assertIsNone(
            NicePathDecomposition([]).validate(Graph(0, [])))

    def test_validate_duck_typed_graph(self):
        g = types.SimpleNamespace(n=3, edges=((0, 1), (1, 2)))
        self.assertIsNone(NicePathDecomposition(PATH_OPS).validate(g))

    def test_width_and_k_single_vertex(self):
        pd = NicePathDecomposition([(0, 1), (0, -1)])
        self.assertEqual(pd.n, 1)
        self.assertEqual(pd.k, 1)
        self.assertEqual(pd.width, 0)


if __name__ == "__main__":
    unittest.main()
