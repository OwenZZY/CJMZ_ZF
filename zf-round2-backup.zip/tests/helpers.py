"""Independent helpers for cross-checking the zf algorithm.

Everything here is deliberately naive and self-contained: it must not
import zf.closure or zf.algorithm, so the tests compare the fast
implementation against a slow, obviously-correct reference.
"""

from __future__ import annotations

import itertools
import random


def naive_white(n, adj, blue):
    """Zero forcing to fixation by repeated full scans (reference).

    Returns the sorted list of vertices still white.  Canonical order:
    lowest-index eligible forcer, one force per scan restart.
    """
    is_blue = [False] * n
    for v in blue:
        is_blue[v] = True
    while True:
        moved = False
        for u in range(n):
            if not is_blue[u]:
                continue
            white_nbs = [w for w in adj[u] if not is_blue[w]]
            if len(white_nbs) == 1:
                is_blue[white_nbs[0]] = True
                moved = True
                break
        if not moved:
            return [v for v in range(n) if not is_blue[v]]


def brute_force_z(n, adj):
    """Exact zero forcing number by enumerating subsets in size order."""
    for k in range(n + 1):
        for subset in itertools.combinations(range(n), k):
            if not naive_white(n, adj, subset):
                return k
    return n  # unreachable for simple graphs


def is_fort(n, adj, fort):
    """True iff no vertex outside `fort` has exactly one neighbor in it."""
    fort = set(fort)
    for v in range(n):
        if v in fort:
            continue
        if sum(1 for w in adj[v] if w in fort) == 1:
            return False
    return True


def arcs_force_all(n, adj, arc_pairs):
    """True iff the arcs drive a valid forcing process from their sources
    that blues every vertex (i.e. the arcs form a forcing arc set of a
    zero forcing process).  Also checks the dipath shape and that every
    arc is an edge of the graph.
    """
    out = {}
    heads = set()
    for u, v in arc_pairs:
        if u in out or v in heads or u == v:
            return False
        if v not in adj[u]:
            return False
        out[u] = v
        heads.add(v)
    # dipath check: following out-arcs never revisits a vertex
    for start in out:
        seen = {start}
        cur = start
        while cur in out:
            cur = out[cur]
            if cur in seen:
                return False
            seen.add(cur)
    # drive the process: sources (no in-arc) start blue
    is_blue = [v not in heads for v in range(n)]
    while True:
        moved = False
        for u, v in out.items():
            if is_blue[u] and not is_blue[v]:
                if sum(1 for w in adj[u] if not is_blue[w]) == 1:
                    is_blue[v] = True
                    moved = True
                    break
        if not moved:
            return all(is_blue)


def nice_pd_ops(n, adj, order):
    """Nice path decomposition ops from a vertex ordering.

    Introduce vertices in `order`; after each introduction, forget every
    active vertex other than the one just introduced whose neighbors have
    all been introduced; finally forget the remaining active vertices.
    Every edge is covered (its later endpoint's introduction bag still
    contains the earlier one), every vertex appears in a bag, and all
    intermediate bags are non-empty.
    """
    ops = []
    active = set()
    introduced = set()
    for v in order:
        ops.append((v, +1))
        active.add(v)
        introduced.add(v)
        for u in sorted(active - {v}):
            if all(w in introduced for w in adj[u]):
                ops.append((u, -1))
                active.remove(u)
    for u in sorted(active):
        ops.append((u, -1))
    return ops


def random_graph(n, p, rng):
    """Random edge list on 0..n-1, each edge present with probability p."""
    return [(u, v) for u in range(n) for v in range(u + 1, n) if rng.random() < p]


def random_order(n, rng):
    order = list(range(n))
    rng.shuffle(order)
    return order


# Standard small graphs -------------------------------------------------

def path_edges(n):
    return [(i, i + 1) for i in range(n - 1)]


def cycle_edges(n):
    return path_edges(n) + ([(0, n - 1)] if n >= 3 else [])


def complete_edges(n):
    return [(u, v) for u in range(n) for v in range(u + 1, n)]


def star_edges(k):
    """Star with center 0 and k leaves 1..k."""
    return [(0, i) for i in range(1, k + 1)]


def petersen_edges():
    outer = [(i, (i + 1) % 5) for i in range(5)]
    inner = [(5 + i, 5 + (i + 2) % 5) for i in range(5)]
    spokes = [(i, 5 + i) for i in range(5)]
    return outer + inner + spokes


def grid_edges(rows, cols):
    def idx(r, c):
        return r * cols + c

    edges = []
    for r in range(rows):
        for c in range(cols):
            if r + 1 < rows:
                edges.append((idx(r, c), idx(r + 1, c)))
            if c + 1 < cols:
                edges.append((idx(r, c), idx(r, c + 1)))
    return edges