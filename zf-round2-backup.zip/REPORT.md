# Report — zf-approx (round 2: 2026-11-21; round 1: 2026-11-20)

**What you need to read: nothing — no pending decisions.** The round-2 closure-canon decision
was approved and implemented (2026-11-21): this repo's closure now matches the parallel
project's arc-for-arc. Technical detail: [docs/closure-review.md](docs/closure-review.md)
(no need to read unless auditing; this is for the spec writer). Round-1 deliverables:
[SPEC-v1.md](SPEC-v1.md), [docs/definitions.md](docs/definitions.md).

---

## 1. What needs to be done (by whom)

- **Nothing required.** Round 2 (closure review + canon alignment) is complete and verified;
  round 1 (SPEC Steps 1–3 + implementation) was already complete.
- Optional, owner, before a public release: the name proposal in [SPEC-v1.md](SPEC-v1.md) §4
  (unchanged from round 1; default: keep the names).

## 2. What is done

- **Round 2 (2026-11-21): review of the parallel project's closure**
  (`CJMZ_ZF/src/zf_npd/zf_closure.py`, read as provided, origin not investigated). Identified its
  published source: Brimkov–Fast–Hicks, EJOR 273(3):889–903, 2019, Algorithm 1 — the exact work
  our paper cites for closure (tex:L813–816); transcribed from the PDF you added
  (`resources/brimkov2018computational.pdf`). Cross-checked empirically: 960 closure trials
  (540 full-graph + 420 region-shaped) and 240 full-algorithm trials. Full write-up:
  [docs/closure-review.md](docs/closure-review.md). Verdict: same engine and same white sets
  (100%); the only behavioral difference is the forcing-order canon (§1 decision); host handling
  differs by design (reference materializes `G[host]`; this repo implements the [L6c] full-graph
  trick SPEC v0 requires). **Canon alignment approved by owner and implemented**:
  [zf/closure.py](zf/closure.py) now uses the smallest-eligible-index min-heap canon (tex:L621);
  [SPEC-v1.md](SPEC-v1.md) §5.2/§6.7 updated; one pinned-arc test updated, one canon-regression
  test added. Post-alignment: **112/112 tests pass**; shipped closure == reference arc-for-arc
  in **960/960** re-run trials; full-algorithm outputs unchanged vs the verified heap variant
  (240/240); demo correct.
- **Round 1 (2026-11-20)** — SPEC Steps 1–3 plus implementation, as below.

- **Step 1** — v0 reviewed; gaps and typos listed in [SPEC-v1.md](SPEC-v1.md) §1, §6.
- **Step 2** — paper read in full; every mathematical definition recorded one item per line in
  [docs/definitions.md](docs/definitions.md), with tex line references; the algorithm box
  (tex:L623–665) transcribed line by line (L1–L8, including sub-lines) in [SPEC-v1.md](SPEC-v1.md) §2.
- **Step 3** — v0 aligned with the paper and assessed viable (§3); names proposed (§4); the entire
  structure completed (§5): interfaces, file layout, and the main loop with all three tricks.
- **Implementation** — package `zf/` (6 modules, stdlib only):
  [graph.py](zf/graph.py) (static graph, 0-based indices, external-name bijection, edge list),
  [arcs.py](zf/arcs.py) (`out_arcs`/`in_arcs` arrays, dynamic `count`, `add`/`delete(heads)`/
  `reverse`/`extend`/`sources`), [decomposition.py](zf/decomposition.py) (`ops=(v,±1)` of length 2n,
  bags, width, D1–D4 validation), [closure.py](zf/closure.py) (queue-based forcing to fixation,
  returns white set + forcing arcs), [algorithm.py](zf/algorithm.py) (the L1–L8 loop with the
  [L3]/[L6b]/[L6c] tricks), [\_\_init\_\_.py](zf/__init__.py).
- **Verification** — 111 unit tests pass (`python3 -m unittest discover -s tests -v`):
  73 structure tests (incl. a 600-step randomized Arcs fuzz), 16 closure tests (incl. 400 random
  graph trials and 600 region checks against an independent naive simulator), 22 algorithm tests
  (280 random graphs n≤8 with random decomposition orders, plus paths/cycles/cliques/stars/
  Petersen/grids/disconnected/edgeless/empty). Every algorithm output is checked against exact
  brute-force `Z(G)`: `S` forces the whole graph; forts are non-empty, pairwise disjoint, and valid;
  `|F| ≤ Z(G) ≤ |S| ≤ (w+1)|F|`; the returned arcs form a forcing arc set with sources exactly `S`
  and `|A| = n − |S|`. Extra evidence beyond the suite: 336 trials of a standalone loop prototype
  (since deleted) and 36 extended stress trials at n=9–11, all passing.
- **Docs/examples** — [README.md](README.md) (quickstart, layout), [examples/demo.py](examples/demo.py)
  (house graph on names {1..5}: returns S={1,3}, one fort, width 2, `2 ≤ 3 = (w+1)|F|`).
- Work was parallelized per AGENTS.md rule 2: the shared API was fixed first (SPEC-v1 §5.2), then
  two subagents wrote disjoint file sets (structures; closure); I wrote the main loop, integration
  tests and docs, reviewed both agents' code, and ran the combined suite.

## 3. What is known / decided (recorded rulings — no action needed)

- You already know the mathematics — you are the paper's author. Nothing here asks you to confirm
  a fact from the paper; the paper statements the code relies on are cited by tex line in
  [SPEC-v1.md](SPEC-v1.md) §2.
- **Forcing-order canon (decided 2026-11-21, owner-approved):** smallest eligible index via
  min-heap, matching the parallel project and the paper's example canon (tex:L621). White sets
  and fort packings are canon-independent; arcs and hence `S` can depend on it — alignment buys
  cross-project output identity. Evidence and the B-F-H Algorithm 1 transcription:
  [docs/closure-review.md](docs/closure-review.md).
- `SPEC.md` and `resources/` are untouched (AGENTS.md rule 7); the updated spec is the new file
  [SPEC-v1.md](SPEC-v1.md). No git state was changed.
- **[L3] trick, as implemented:** an introduce step keeps `W = ∅` (the new vertex joins the bag
  blue, and adding a blue vertex never invalidates a forcing move), so the loop adds it to
  `bag`/`region` and continues without calling `closure`. Same argument, second skip: forgetting a
  vertex already in `X_t` leaves the blue set and the graph unchanged. Closure is called only when
  forgetting a vertex outside `X_t`. This is the "[L3] update" that maintains the [L6c] coloring.
- **[L6b] trick:** `S` is never maintained; (L5)/(L6b) omitted, `S = A.sources()` once at the end
  (paper remark tex:L685).
- **[L6c] trick:** no induced subgraph is ever built; `closure` runs on the full graph with
  blue = `(V \ X_t^z) ∪ X_t ∪ X_z`. Exact because contiguity (D2) forces every inside-neighbor of an
  outside vertex into `X_t ∪ X_z` (blue), so outside vertices never force. Used at (L3b), (L6c), (L7a).
- Index convention: `len(ops) = 2n`, bags `X_0..X_{2n}`, `k = 2n−1`, op `z−1` (0-based) produces `X_z`.
- Input suitability = D1–D4 + every vertex in some bag (checked by `validate`); this is weaker than
  the paper's connectedness assumption, so edgeless/disconnected graphs also work.
- Canonical forcing order: deterministic FIFO queue seeded in index order (a canonical choice in
  the sense of tex:L621); the whole algorithm is deterministic.

## 4. Agent findings (informational — no need to read unless auditing)

- **v0 typo 1 ([L6c] blue set).** v0 wrote `V \ V(G(t,z)) ∪ X_t^z`, which literally is all of `V`
  (since `X_t^z = V(G(t,z))`) and would make `W = ∅` always. Resolved to `(V \ X_t^z) ∪ X_t ∪ X_z`,
  forced by consistency with (L3b). Recorded in [SPEC-v1.md](SPEC-v1.md) §6.1.
- **v0 typo 2 (`arcs.delete`).** v0's "removes `out_arcs[j]` and `in_arc[i]`" swaps the indices;
  deleting by head `j` clears `in_arcs[j]` and `out_arcs[i]` for `i = in_arcs[j]`. Implemented that
  way — it is exactly what (L6d) needs (`A.delete(X_z)`). §6.2.
- **The [L3] skip was verified, not assumed:** a standalone prototype of the loop (naive inline
  primitives) passed 336 random trials before integration; it also caught an error in my own mental
  trace of P3 (the final `A.reverse()` flips the chain, so P3 returns the *other* endpoint).
- **Boundary subtlety in [L6c]:** "outside vertices never force" needs the D2 boundary condition;
  it holds for the algorithm's regions `X_t^z` but not for arbitrary vertex subsets. The closure
  tests pin both the valid case and a counterexample for arbitrary regions.
- **Brute-force sanity:** `Z(Petersen) = 5` reproduced; `Z(K_n) = n−1`, `Z(K_{1,k}) = k−1`,
  `Z(P_n) = 1` all matched by the returned sets where the decomposition allowed it.
- The two subagents resolved minor contract edge cases (out-of-range indices → `ValueError`,
  atomic `extend`, `from_bags([])` → `ValueError`); all resolutions are documented in their test
  files and consistent with SPEC-v1 §5.2. One integrator fix afterwards: non-comparable external
  names now raise `ValueError` (was `TypeError`) in `Graph`.